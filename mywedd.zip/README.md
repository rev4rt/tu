Wedding website built with Next.js, TypeScript, and Tailwind

Live Demo: <a href="https://darrellrahan-wedding.vercel.app">darrellrahan-wedding.vercel.app</a>
